import React, { useEffect, useState } from 'react';
import { Button, Col, Container, Form, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom"
import axios from 'axios';

function Department() {

  const navigate = useNavigate();

  let Sn = 1;
  let [data, setData] = useState([])
  
  let apiURL = 'http://localhost:4000/deptdata';
  async function getData() {
    let res = await axios.get(apiURL);
    console.log(res.data);
    setData(res.data);
  }
  useEffect(() => {
    getData()
  }, [])

  function viewdept(id) {
    navigate('/dashboard/department/view_dept', { state: { id: id } })
  }

  return (
    <>

      <div className='col m-0 p-0'>
        <div className='p-2 d-flex justify-content-center shadow'>
          <h4>Manage Department</h4>
        </div>
        <Link to="/dashboard/department/add_department" className='btn btn-success mt-3 m-2 mb-1 p-3 '>Add Department</Link>
        <div style={{ float: 'right' }}>
          <Container className="mt-4">
            <Row >
              <Col sm={12}>
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search"
                    className="me-2"
                    aria-label="Search"
                  />
                  <Button>
                    Search
                  </Button>
                </Form>
              </Col>
            </Row>
          </Container>
        </div>
        <hr></hr>
      </div>
      <div className='example5'>
      <div className='m-4'>
        <table class="table table-striped ">
          <thead>
            <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
              <th scope="col">S no.</th>
              <th scope="col">Department</th>
              <th scope='col'>Strength</th>
              
              <th scope="col">View</th>
            </tr>
          </thead>
          <tbody>
            {
              data.map((item, index) => {
                return (
                  <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
                    <th scope="row">{Sn++}</th>
                    <td>{item.dept_name}</td>
                    <td>{item.duplicate_count}</td>
                    
                    <td><button onClick={() => { viewdept(item.dept_id) }} type="button" class="btn btn-primary m-1">View</button></td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
      </div>
    </>
  )
}

export default Department;