import React from 'react';
import { NavLink, Outlet, useNavigate,useLocation } from 'react-router-dom';
import axios from 'axios';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';

function EmpDashboard() {
  const navigate = useNavigate();
  let location = useLocation();
    const empmail = location.state.id;

  const EmpHome = () => {
    navigate('/empdashboard/emphome', { state: { id: empmail } });
  }
  const attendance = () => {
    navigate('/empdashboard/attendance', { state: { id: empmail } });
  }
  const empleave = () => {
    navigate('/empdashboard/empleave', { state: { id: empmail } });
  }
  const payroll = () => {
    navigate('/empdashboard/payroll', { state: { id: empmail } });
  }
  const empprofile = () => {
    navigate('/empdashboard/profile', { state: { id: empmail } });
  }
  const SignOut = (e) => {
    e.preventDefault();
    axios.put('http://localhost:4000/attendanceempout')
      .then(response => {
        console.log("Response data:", response.data);
        if (response.data.loginStatus) {
          console.log("Success");
        } else {
          console.log("error")
        }
      })
      .catch(error => {
        console.error("Error occurred during sign out:", error);
      });

    alert("Press OK for Sign Out")
    navigate('/auth');
  }
  return (
    <>
      <div style={{ display: "flex" }}>
        <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
          <CDBSidebar textColor="#fff" backgroundColor="#333" >
            <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
              <a href="/dashboard/home" className="text-decoration-none" style={{ color: 'inherit' }}>
                Employee 
              </a>
            </CDBSidebarHeader>
            <CDBSidebarContent classname="sidebar-content" >
              <CDBSidebarMenu >
                <NavLink activeClassName="activeClicked" to="/dashboard/employees"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-bars" onClick={EmpHome} >Dashboard</CDBSidebarMenuItem>

                <NavLink exact activeClassName="activeClicked" to="/dashboard/department"></NavLink>
                <CDBSidebarMenuItem icon="table" onClick={attendance}>Attendance</CDBSidebarMenuItem>

                <NavLink exact activeClassName="activeClicked" to="/dashboard/leaveType"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-tasks" onClick={empleave}>Leave</CDBSidebarMenuItem>

                <NavLink activeClassName="activeClicked" to="/dashboard/employees"></NavLink>
                <CDBSidebarMenuItem icon="fa-solid fa-file" onClick={payroll}>Payroll</CDBSidebarMenuItem>

                <NavLink exact activeClassName="activeClicked" to="/dashboard/leaveReq"></NavLink>
                <CDBSidebarMenuItem icon="fa-ragular fa-user" onClick={empprofile}>Profile</CDBSidebarMenuItem>

              </CDBSidebarMenu>
            </CDBSidebarContent>
            <NavLink exact to="/profile" activeClassName="activeClicked"></NavLink>
            <CDBSidebarMenuItem icon="user" onClick={SignOut}>Sign out</CDBSidebarMenuItem>

          </CDBSidebar>
        </div>
        <div className='col p-0 m-0'>
          <Outlet />
        </div>
      </div>
    </>
  );
};

export default EmpDashboard;