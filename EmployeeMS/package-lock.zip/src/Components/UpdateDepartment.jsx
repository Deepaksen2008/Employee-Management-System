import React from 'react'

function UpdateDepartment() {
  return (
   <>
    <div>
      UpdateDepartment
    </div>
   </>
  )
}

export default UpdateDepartment