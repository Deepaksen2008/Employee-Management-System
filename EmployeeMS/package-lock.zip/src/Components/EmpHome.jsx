import React from 'react'
import Card from 'react-bootstrap/Card';
import { useLocation, useNavigate } from "react-router-dom"

function EmpHome() {
  let location = useLocation();
  const empId = location.state.id;

  const navigate = useNavigate();
  const Applyforleave = () => {
    navigate('/empdashboard/empleave/applyforleave', { state: { id: empId } });
  }
  const Approvedleave = () => {
    navigate('', { state: { id: empId } });
  }
  const Rejectleave = () => {
    navigate('', { state: { id: empId } });
  }
  const Payroll = () => {
    navigate('/empdashboard/payroll', { state: { id: empId } });
  }
  const Viewattendance = () => {
    navigate('/empdashboard/attendance', { state: { id: empId } });
  }
  const Myprofile = () => {
    navigate('/empdashboard/profile', { state: { id: empId } });
  }

  return (
    <>
      <div>
        <div className='d-flex gap-3 m-4 mt-5 justify-content-center'>
          <Card
            style={{
              width: '15rem',
              backgroundImage: 'linear-gradient(to right, #007bff, #17a2b8)' 
            }}
            className="mb-2"
            onClick={Applyforleave}
          >
            <Card.Header><h5>ᴀᴘᴘʟʏ ꜰᴏʀ ʟᴇᴀᴠᴇ</h5></Card.Header>
            <Card.Body>
              <Card.Title style={{ fontSize: '2.5em' }}>08 </Card.Title>
            </Card.Body>
          </Card>
          <Card
            style={{
              width: '15rem',
              backgroundImage: 'linear-gradient(to right, #00b894, #00cec9)' 
            }}
            className="mb-2"
            onClick={Approvedleave}
          >
            <Card.Header><h5>ᴀᴘᴘʀᴏᴠᴇᴅ ʟᴇᴀᴠᴇ</h5></Card.Header>
            <Card.Body>
              <Card.Title style={{ fontSize: '2.5em' }}>08 </Card.Title>
            </Card.Body>
          </Card>

          <Card
            style={{
              width: '15rem',
              backgroundImage: 'linear-gradient(to right, #FFD700, #FFA500, #FF6347)' 
            }}
            className="mb-2"
            onClick={Rejectleave}
          >
            <Card.Header><h5>ʀᴇᴊᴇᴄᴛᴇᴅ ʟᴇᴀᴠᴇ</h5></Card.Header>
            <Card.Body>
              <Card.Title style={{ fontSize: '2.5em' }}>08 </Card.Title>
            </Card.Body>
          </Card>
          <Card
            style={{
              width: '15rem',
              backgroundImage: 'linear-gradient(to right, #ff69b4, #ffdab9)' 
            }}
            className="mb-2"
            onClick={Payroll}
          >
            <Card.Header><h5>ᴘᴀʏʀᴏʟʟ</h5></Card.Header>
            <Card.Body>
              <Card.Title style={{ fontSize: '2.5em' }}>08 </Card.Title>
            </Card.Body>
          </Card>
        </div>
      </div>
      <hr></hr>
      <div className='p-0.5 d-flex justify-content-center'>
        <h4>ꜱᴛᴀᴛᴜꜱ</h4>
      </div>
      <hr></hr>
      <div>
        <div class="container mt-5 mb-3">
          <div class="row m-5">
            <div className="col-md-6" style={{ cursor: 'pointer' }} onClick={Viewattendance}>
              <div className="card p-3 mb-2 shadow" style={{
                backgroundImage: 'linear-gradient(to right, #ff6b6b, #ffb8b8)' 
              }}>
                <div className="d-flex justify-content-between">
                  <div className="d-flex flex-row align-items-center">
                    <div className="icon"> <i className="fa-brands fa-bootstrap"></i></div>
                    <div className="ms-2 c-details">
                      <h6 className="mb-0">Pending</h6> <span>1 days ago</span>
                    </div>
                  </div>
                </div>
                <div className="mt-5">
                  <h3 className="heading">ᴠɪᴇᴡ ᴀᴛᴛᴇɴᴅᴀɴᴄᴇ</h3>
                  <div className="mt-5">
                    <div className="mt-3"> <span className="text1">15 Request <span className="text2">in last week</span></span> </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6" style={{ cursor: 'pointer' }} onClick={Myprofile}>
              <div className="card p-3 mb-2 shadow" style={{
                backgroundImage: 'linear-gradient(to right, #2ecc71, #27ae60)' // Unique multi-color gradient of green shades
              }}>
                <div className="d-flex justify-content-between">
                  <div className="d-flex flex-row align-items-center">
                    <div className="icon"><i className="fa-brands fa-superpowers"></i></div>
                    <div className="ms-2 c-details">
                      <h6 className="mb-0">Rejected</h6> <span>2 days ago</span>
                    </div>
                  </div>
                </div>
                <div className="mt-5">
                  <h3 className="heading">ᴍʏ ᴘʀᴏꜰɪʟᴇ</h3>
                  <div className="mt-5">
                    <div className="mt-3"> <span className="text1">10 Rejected <span className="text2">out of 28</span></span> </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default EmpHome