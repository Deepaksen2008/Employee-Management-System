import AttendanceStatus from './AttendanceStatus';
import axios from 'axios';
import React from 'react'
import { Button, Col, Container, Form, Row } from "react-bootstrap";
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';


function Attendance() {
  // const navigate = useNavigate();

  let Sn = 1;
  let [data, setData] = useState([])
  let apiURL = 'http://localhost:4000/attendanceView';
  async function getData() {
    let res = await axios.get(apiURL);
    console.log(res.data);
    setData(res.data);
  }
  let fn = () => {
    getData()
  }
  useEffect(fn, [])

  function UpdateAtt() {
    axios.put('http://localhost:4000/attendanceupdate').then(response => {
      window.location.reload();
      console.log("Response data:", response.data);
    }).catch(error => {
      window.location.reload();
      console.error("Error occurred during Update:", error);
    });
  }

  function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', options);
  }

  return (
    <>
      <div className='col m-0 p-0'>
        <div className='p-2 d-flex justify-content-center shadow'>
          <h4>Employees</h4>
        </div>
        <Button className="btn btn-success btn-lg m-3 p-2" onClick={() => { UpdateAtt(); getData() }} >Update</Button>
        <div style={{ float: 'right' }}>
          <Container className="mt-4">
            <Row >
              <Col sm={12}>
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search"
                    className="me-2"
                    aria-label="Search"
                  />
                  <Button>
                    Search
                  </Button>
                </Form>
              </Col>
            </Row>
          </Container>
        </div>
        <hr></hr>
      </div>
      <div className='m-4'>
        <table class="table table-striped shadow ">
          <thead>
            <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
              <th scope="col">Sr No.</th>
              <th scope="col">Employee Name</th>
              <th scope="col">Date</th>
              <th scope="col">Login </th>
              <th scope="col">Logout</th>
              <th scope="col">Effective Hour</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
            {
              data.map((item, index) => {
                return (
                  <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
                    <th scope="row">{Sn++}</th>
                    <td >{item.emp_name}</td>
                    <td >{formatDate(item.date)}</td>
                    <td >{item.in_time}</td>
                    <td >{item.out_time}</td>
                    <td >{item.total_login_hr}</td>
                    <td><AttendanceStatus color={item.attendance_status}/></td>
                      </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </>
  )
}

export default Attendance