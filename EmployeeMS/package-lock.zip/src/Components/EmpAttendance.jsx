import axios from 'axios';
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import AttendanceStatus from './AttendanceStatus';

function EmpAttendance() {

    let Sn=1;
    const [value, setValue] = useState({ emp_id: '' });
    const [data, setData] = useState([]);
    const location = useLocation();
    const empId = location.state.id;

    const handleSubmit = async (event) => {
        event.preventDefault();
        await empData();
    };

    async function empData() {
        let apiURL = `http://localhost:4000/empattendance?empid=${value.emp_id}`;
        let res = await axios.get(apiURL);
        setData(res.data);
        console.log(res.data);
    }

    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', options);
    }

    return (
        <>
            <div>
                <div class="signup-form shadow mt-3">
                    <form onSubmit={handleSubmit}>
                        <p><h2>Attendance Details</h2></p>
                        <div class="form-group d-flex gap-3" >
                            <label>Employee ID</label>
                            <input type="text" class="form-control" onChange={(e) => setValue({ ...value, emp_id: e.target.value })} />
                            <button to='' class="btn btn-primary btn-lg">Search</button>
                        </div>
                    </form>

                </div>
                <div>
                </div>
                <div className='m-4'>
                    <table class="table table-striped shadow ">
                        <thead>
                            <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
                                <th scope="col">Date</th>
                                <th scope="col">Name</th>
                                <th scope="col">Leave</th>
                                <th scope="col">In time</th>
                                <th scope="col">Out time</th>
                                <th scope="col">Effective Hour</th>
                                <th scope="col">Status</th>
                                <th scope="col">Remark</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((item, index) => (
                                <tr style={{ verticalAlign: 'middle', textAlign: 'center' }}>
                                    <th scope="row">{Sn++}</th>
                                    <td >{item.emp_name}</td>
                                    <td >{formatDate(item.date)}</td>
                                    <td >{item.in_time}</td>
                                    <td >{item.out_time}</td>
                                    <td >{item.total_login_hr}</td>
                                    <td><AttendanceStatus color={item.attendance_status} /></td>
                                    <td><button to="" type="button" class="btn btn-primary">Action</button></td>            </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}

export default EmpAttendance