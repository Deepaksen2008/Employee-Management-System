import axios from 'axios';
import { React, useState, useEffect } from 'react'
import { useLocation } from "react-router-dom"


function EmpProfile() {

  
  let location = useLocation();
  const empmail = location.state.id;
  
  const [data, setData] = useState([])
  async function empData() {
    let apiURL = `http://localhost:4000/empprofile?empmail=${empmail}`;
    let res = await axios.get(apiURL)
    setData(res.data);
    console.log(res.data);
    
  }
  useEffect(() => {
    empData()
  }, [])
  
  function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', options);
  }

  const [value, setValue] = useState({
    emp_name: '',
    emp_mob: '',
    emp_email: '',
    emp_dob: '',
    emp_add: '',
    emp_city: ''
  });
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(value);
  
    // const newValue = value.emp_name;
    // const dataToUpdate = { emp_name: newValue }; 

    // const newValue1 = value.emp_name;
    // const dataToUpdate = { emp_city: newValue1 };

    // const newValue2 = value.emp_name;
    // const dataToUpdate = { emp_dob: newValue };

    // const newValue3 = value.emp_name;
    // const dataToUpdate = { emp_email: newValue };

    // const newValue = value.emp_name;
    // const dataToUpdate = { emp_mob: newValue };

    // const newValue = value.emp_add;
    // const dataToUpdate = { emp_name: newValue };
  
    // console.log(dataToUpdate);
  
    axios.patch(`http://localhost:4000/employees?emp_id=${empmail}`, value)
      .then(result => {
        console.log(result.data);
      })
      .catch(err => console.log(err));
  };
  
  return (
    <>
      {data.map((item, index) => {
        return (
          <div>
            <div className='example2'>
              <div class="signup-form shadow mt-3">
                <form>
                  <p>Employee ID  <h2>{item.emp_id}</h2></p>
                  <hr />
                  <div className='d-flex gap-4'>
                    <div class="form-group w-50">
                      <label for="birthday">First name</label>
                      <text type="text" class="form-control" > {item.emp_name.split(" ")[0]}</text>
                    </div>
                    <div class="form-group w-50">
                      <label for="birthday">Last name</label>
                      <div class="-prepend">
                      </div>
                      <text type="text" class="form-control" name="email" placeholder="Last name" required="required" > {item.emp_name.split(" ")[1]}</text>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="birthday">Department</label>
                    <text type="number" class="form-control" name="email" placeholder="Last name" required="required" > {item.dept_name}</text>
                  </div>
                  <div className='d-flex gap-4'>
                    <div class="form-group w-50">
                      <label for="birthday">Email</label>
                      <text type="text" class="form-control" > {item.emp_email}</text>
                    </div>
                    <div class="form-group w-50">
                      <label for="birthday">Contact number</label>
                      <div class="-prepend">
                      </div>
                      <text type="number" class="form-control" name="email" placeholder="Last name" required="required" > {item.emp_mob}</text>
                    </div>
                  </div>
                  <div className='d-flex gap-4'>
                    <div class="form-group w-50">
                      <label for="birthday">DOB</label>
                      <text type="date" class="form-control" name="password" placeholder="Date of birth" required="required">{formatDate(item.emp_dob)}</text>
                    </div>
                    <div class="form-group w-50">
                      <label for="birthday">DOJ</label>
                      <text type="date" class="form-control" name="password" placeholder="Date of birth" required="required">{formatDate(item.emp_doj)}</text>
                    </div>
                  </div>
                  <div className='d-flex gap-4'>
                    <div class="form-group w-50">
                      <label for="birthday">Address</label>
                      <text type="date" class="form-control" name="password" placeholder="Date of birth" required="required">{item.emp_add}</text>
                    </div>
                    <div class="form-group w-50">
                      <label for="birthday">City</label>
                      <text type="date" class="form-control" name="password" placeholder="Date of birth" required="required">{item.emp_city}</text>
                    </div>
                  </div>
                  <div class="form-group">
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                      Update
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )
      })}
      <div>
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">

            {
              data.map((item, index) => {
                return (
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" />
                    </div>
                    <div class="modal-body">
                      <div class="signup-form ">
                        <form onSubmit={handleSubmit}>
                          <p>Employee Name  <h2>{item.emp_name}</h2></p>
                          <hr />

                          <div class="form-group">
                            <label>Name</label>
                            <div class="-prepend">
                            </div>
                            <input type="text" class="form-control" onChange={(e) => setValue({ ...value, emp_name: e.target.value })} placeholder={item.emp_name} />
                          </div>

                          <div class="form-group">
                            <label>Mobile</label>
                            <input type="number" class="form-control" onChange={(e) => setValue({ ...value, emp_mob: e.target.value })} placeholder={item.emp_mob} />
                          </div>
                          <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" onChange={(e) => setValue({ ...value, emp_email: e.target.value })} placeholder={item.emp_email} />
                          </div>
                          <div class="form-group">
                            <label>DOB</label>
                            <input type="date" class="form-control" onChange={(e) => setValue({ ...value, emp_dob: e.target.value })} placeholder={item.emp_dob} />
                          </div>
                          <div class="form-group">
                            <label>Address</label>
                            <input type="text" class="form-control" onChange={(e) => setValue({ ...value, emp_add: e.target.value })} placeholder={item.emp_add} />
                          </div>
                          <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control" onChange={(e) => setValue({ ...value, emp_city: e.target.value })} placeholder={item.emp_city} />
                          </div>
                          <div class="form-group">
                            <button type="submit" class="btn btn-success btn-lg">Update Data</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                )
              })}
          </div>
        </div>
      </div>
    </>
  )
}

export default EmpProfile