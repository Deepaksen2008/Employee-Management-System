import axios from 'axios';
import React,{useState, useEffect} from 'react';
import { useLocation } from 'react-router-dom';


function PayOut() {

    const location = useLocation();
    const emp = location.state.emp;
    const empId = location.state.empId;

    let [data, setData] = useState([]);
    async function empData() {
        let apiURL = `http://localhost:4000/empsalarydetail?q=${emp}`;
        let res = await axios.get(apiURL)
        setData(res.data);
        console.log(res.data);
    }
    useEffect(() => {
        empData()
    }, [])

    function formatIndianRupee(amount) {
        let [integerPart, decimalPart] = amount.toString().split(".");
        integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return '₹' + integerPart + (decimalPart ? "." + decimalPart : "");
    }
    
    return (
        <>
            <div className='example3'>
            {data.map((item, index) => (
                <div class="signup-form shadow mt-2">
                    <form>
                        <p>{item.emp_name}<h2>{item.emp_id}</h2></p>
                        <hr />
                        <div className='d-flex gap-4'>
                            <div class="form-group w-50">
                                <label for="birthday">Name</label>
                                <text type="text" class="form-control" name="username">{item.emp_name}</text>
                            </div>
                            <div class="form-group w-50">
                                <label for="birthday">Department:</label>
                                <text type="text" class="form-control" name="username">{item.dept_name}</text>
                            </div>
                        </div>
                        <div className='d-flex gap-4'>
                            <div class="form-group w-50">
                                <label for="birthday">Total working days</label>
                                <text type="text" class="form-control" name="username">26</text>
                            </div>
                            <div class="form-group w-50">
                                <label for="birthday">Present</label>
                                <text type="text" class="form-control" name="username">21</text>
                            </div>
                        </div>
                        <div className='d-flex gap-4'>
                            <div class="form-group w-50">
                                <label for="birthday">Monthly CTC</label>
                                <text type="text" class="form-control" name="username">{formatIndianRupee(Math.round(item.sal_ctc / 12))}</text>
                            </div>
                            <div class="form-group w-50">
                                <label for="birthday">Net Salary</label>
                                <text type="text" class="form-control" name="username">{formatIndianRupee(Math.round(((((item.sal_ctc) * 0.70) / 12)/26)*21))}</text>
                            </div>
                        </div>
                    </form>
                </div>
                ))}
            </div>
        </>
    )
}

export default PayOut