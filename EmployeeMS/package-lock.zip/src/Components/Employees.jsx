import Pagination from 'react-bootstrap/Pagination';
import React, { useEffect, useState } from 'react';
import { Button, Col, Container, Form, Row } from "react-bootstrap";
import { Link, useNavigate, useLocation } from "react-router-dom"
import { Alert } from './Alert';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faTrash } from '@fortawesome/free-solid-svg-icons';

import { faEdit, faTrash, faMoneyBillWave, faEye } from '@fortawesome/free-solid-svg-icons';

import { RiDeleteBin6Line } from "react-icons/ri";
import { FaUserEdit } from "react-icons/fa";
import { FaRupeeSign } from "react-icons/fa";
import { FaStreetView } from "react-icons/fa6";



function Employees() {
  const navigate = useNavigate();
  let location = useLocation();
  const empId = location.state.id;

  let [data, setData] = useState([])
  const [page, setPage] = useState([1])

  let apiURL = 'http://localhost:4000/employees';
  async function getData() {
    let res = await axios.get(apiURL);
    console.log(res.data);
    setData(res.data);
  }
  let fn = () => {
    getData()
  }
  useEffect(fn, [])

  const [alert, setAlert] = useState({ msg: '', type: '' });
  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type
    });
  };

  async function deleteData(eid) {
    let dltURL = await axios.delete(`${apiURL}?emp_id=${eid}`);
    showAlert(`Employee ID ${eid} has been successfully deleted`, "danger");
    console.log(dltURL.data)
  }

  function dashboard(id) {
    navigate('/dashboard/employees/empdetails', { state: { id: id } })
  }

  function salarydet(id) {
    navigate('/dashboard/employees/empsalary', { state: { id: id } })
  }

  function upempdata(id) {
    navigate('/dashboard/employees/editempdata', { state: { id: id } })
  }

  const selectPageHandler = (selectedPage) => {
    setPage(selectedPage)
  }

  return (
    <>
      <div className='col m-0 p-0'>
        <div className='p-2 d-flex justify-content-center shadow'>
          <h4>Employees</h4>
        </div>
        <Link to="/dashboard/employees/edit_employee" className='btn btn-success mt-3 m-2 mb-1 p-3'>Add Employees</Link>
        <div style={{ float: 'right' }}>
          <Container className="mt-4">
            <Row>
              <Col sm={12}>
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search"
                    className="me-2"
                    aria-label="Search"
                  />
                  <Button>Search</Button>
                </Form>
              </Col>
            </Row>
          </Container>
        </div>
        <hr />
      </div>
      <div className='m-0'>
            <Alert alert={alert} />
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Sr no.</th>
                        <th>Emp ID</th>
                        <th>Full Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.slice(page * 5 - 5, page * 5).map((item, index) => (
                        <tr key={index}>
                            <td>{(page - 1) * 5 + index + 1}</td>
                            <td>{item.emp_id}</td>
                            <td>{item.emp_name}</td>
                            <td>{item.emp_mob}</td>
                            <td>{item.emp_email}</td>
                            <td>
                                <button onClick={() => upempdata(item.emp_id)} type="button" className="btn btn-success m-1">
                                    <FontAwesomeIcon icon={faEdit} color="white" />
                                </button>
                                <button type="button" className="btn btn-danger m-1" onClick={() => { deleteData(item.emp_id); getData(); }}>
                                    <FontAwesomeIcon icon={faTrash} color="white" />
                                </button>
                                <button onClick={() => salarydet(item.emp_id)} type="button" className="btn btn-warning m-1">
                                    <FontAwesomeIcon icon={faMoneyBillWave} color="white" />
                                </button>
                                <button onClick={() => dashboard(item.emp_id)} type="button" className="btn btn-primary m-1">
                                    <FontAwesomeIcon icon={faEye} color="white" />
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Pagination className='justify-content-center'>
                <Pagination.First onClick={() => selectPageHandler(1)} />
                <Pagination.Prev onClick={() => selectPageHandler(page - 1)} disabled={page === 1} />
                <Pagination.Item active={true}>
                    {page}
                </Pagination.Item>
                <Pagination.Next onClick={() => selectPageHandler(page + 1)} disabled={page === Math.ceil(data.length / 5)} />
                <Pagination.Last onClick={() => selectPageHandler(Math.ceil(data.length / 5))} />
            </Pagination>
        </div>

    </>
  );
}
export default Employees
