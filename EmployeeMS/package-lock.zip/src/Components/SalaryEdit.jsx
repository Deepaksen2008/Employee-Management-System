import axios from 'axios';
import { React, useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom';

function SalaryEdit() {

    const location = useLocation();
    const emp = location.state.emp;
    const empId = location.state.empId;

    let [data, setData] = useState([]);
    async function empData() {
        let apiURL = `http://localhost:4000/empsalarydetail?q=${emp}`;
        let res = await axios.get(apiURL)
        setData(res.data);
        console.log(res.data);
    }
    useEffect(() => {
        empData()
    }, [])

    function formatIndianRupee(amount) {
        let [integerPart, decimalPart] = amount.toString().split(".");
        integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return '₹' + integerPart + (decimalPart ? "." + decimalPart : "");
    }

    return (
        <>
            <div className='example1'>
                {data.map((item, index) => (
                    <div class="signup-form shadow mt-3">
                        <form>
                            <p>Employee ID<h2>{item.emp_id}</h2></p>
                            <hr />
                            <div className='d-flex gap-4'>
                                <div class="form-group w-50">
                                    <label>Name</label>
                                    <text type="text" class="form-control" name="username">{item.emp_name}</text>
                                </div>
                                <div class="form-group w-50">
                                    <label>Department</label>
                                    <text type="text" class="form-control" name="username">{item.dept_name}</text>
                                </div>
                            </div>
                            <div className='d-flex gap-4'>
                                <div class="form-group w-50">
                                    <label>Email ID</label>
                                    <text type="text" class="form-control" name="username">{item.emp_email}</text>
                                </div>
                                <div class="form-group w-50">
                                    <label>Phone</label>
                                    <text type="text" class="form-control" name="username">{item.emp_mob}</text>
                                </div>
                            </div>

                            <hr />
                            <div className='d-flex gap-4'>
                                <div class="form-group w-50">
                                    <label>Total working days</label>
                                    <text type="text" class="form-control" name="username">26</text>
                                </div>
                                <div class="form-group w-50">
                                    <label>Present</label>
                                    <text type="text" class="form-control" name="username">24</text>
                                </div>
                            </div>
                            <div className='d-flex gap-4'>
                                <div class="form-group w-50">
                                    <label>Monthly CTC</label>
                                    <text type="text" class="form-control" name="username">{formatIndianRupee(Math.round(item.sal_ctc / 12))}</text>
                                </div>
                                <div class="form-group w-50">
                                    <label>Net Salary</label>
                                    <text type="text" class="form-control" name="username">{formatIndianRupee(Math.round(((item.sal_ctc) * 0.70) / 12))}</text>
                                </div>
                            </div>
                        </form>
                    </div>
                ))}
            </div>
        </>
    )
}

export default SalaryEdit