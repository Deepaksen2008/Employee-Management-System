import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { Button } from 'react-bootstrap';



function Dashboard() {

  let location = useLocation();
  const empId = location.state.id;

  const navigate = useNavigate();
  const dashboard = () => {
    navigate('/dashboard/home', { state: { id: empId } });
  }
  const department = () => {
    navigate('/dashboard/department', { state: { id: empId } });
  }
  const employee = () => {
    navigate('/dashboard/employees', { state: { id: empId } });
  }
  const leavetype = () => {
    navigate('/dashboard/leavetype', { state: { id: empId } });
  }
  const salary = () => {
    console.log(empId);
    navigate('/dashboard/salary', { state: { id: empId } });
  }
  const attendance = () => {
    navigate('/dashboard/attendance', { state: { id: empId } });
  }
  const leavereq = () => {
    navigate('/dashboard/leaveReq', { state: { id: empId } });
  }

  const SignOut = (e) => {
    e.preventDefault();
    axios.put('http://localhost:4000/attendanceempout')
      .then(response => {
        console.log("Response data:", response.data);
        if (response.data.loginStatus) {
          console.log("Success");
        } else {
          console.log("error")
        }
      })
      .catch(error => {
        console.error("Error occurred during sign out:", error);
      });

    alert("Press OK for Sign Out")
    navigate('/auth');
  }

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [sessionDuration, setSessionDuration] = useState(0);
  const [activeTime, setActiveTime] = useState(0);

  useEffect(() => {
    let intervalId;
    if (isLoggedIn) {
      intervalId = setInterval(() => {
        setActiveTime(prevTime => prevTime + 1); // Increment active time every second
      }, 1000);
    }
    return () => clearInterval(intervalId); // Cleanup on component unmount or logout
  }, [isLoggedIn]);

  const formatTime = (timeInSeconds) => {
    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = timeInSeconds % 60;

    if (hours > 0) {
      return `${hours} hrs${hours > 1 ? 's' : ''} ${minutes} min${minutes > 1 ? 's' : ''} ${seconds} sec${seconds > 1 ? 's' : ''}`;
    } else if (minutes > 0) {
      return `${minutes} min${minutes > 1 ? 's' : ''} ${seconds} sec${seconds > 1 ? 's' : ''}`;
    } else {
      return `${seconds} sec${seconds > 1 ? 's' : ''}`;
    }
  };

  const handleLogin = () => {
    localStorage.setItem('loginTime', new Date().getTime());
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    const loginTime = localStorage.getItem('loginTime');
    const logoutTime = new Date().getTime();
    const durationInSeconds = (logoutTime - parseInt(loginTime)) / 1000; // Convert milliseconds to seconds
    console.log(loginTime, logoutTime);
    setSessionDuration(durationInSeconds);
    console.log(durationInSeconds, sessionDuration);
    localStorage.removeItem('loginTime');

    setIsLoggedIn(false);
    // setActiveTime(0); // Reset active time
  };


  return (
    <>
      <div style={{ display: "flex" }}>
        <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
          <CDBSidebar textColor="#fff" backgroundColor="#333" >
            <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
              <a href="/dashboard/home" className="text-decoration-none" style={{ color: 'inherit' }}>
                <h6><strong>Admin</strong></h6>
                <h6>{formatTime(activeTime)} </h6>
              </a>

              <Button
                onClick={isLoggedIn ? handleLogout : handleLogin}
                className={isLoggedIn ? 'awayButton' : 'activeButton'}
              >
                {isLoggedIn ? 'Away' : 'Active'}
              </Button>

            </CDBSidebarHeader>
            <CDBSidebarContent classname="sidebar-content" >
              <CDBSidebarMenu >
                <NavLink className="activeClicked" to="/dashboard/employees"></NavLink>
                <CDBSidebarMenuItem icon="fas fa-th" onClick={dashboard} >Dashboard</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/department"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-tasks" onClick={department}>Department</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/leaveType"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-user" onClick={leavetype}>Leave type</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/employees"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-users" onClick={employee}>Employee</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/salary"></NavLink>
                <CDBSidebarMenuItem icon="fas fa-file" onClick={salary}>Salary</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/salary"></NavLink>
                <CDBSidebarMenuItem icon="fas fa-table" onClick={attendance}>Attendance</CDBSidebarMenuItem>

                <NavLink className="activeClicked" to="/dashboard/leaveReq"></NavLink>
                <CDBSidebarMenuItem icon="fa fa-h-square" onClick={leavereq}>Leave Request</CDBSidebarMenuItem>

              </CDBSidebarMenu>
            </CDBSidebarContent>
            <CDBSidebarMenuItem icon="fa fa-user" onClick={SignOut}>Sign out</CDBSidebarMenuItem>

          </CDBSidebar>
        </div>
        <div className='col p-0 m-0'>
          <Outlet />
        </div>
      </div>
    </>
  );
};

export default Dashboard;