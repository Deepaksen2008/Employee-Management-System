import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import Card from 'react-bootstrap/Card';
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts'; // Importing from Recharts


export default function Home() {

  let location = useLocation();
  const empId = location.state.id;

  let [data, setData] = useState([]);
  async function empData() {
    let apiURL = `http://localhost:4000/listdata`;
    let res = await axios.get(apiURL)
    setData(res.data);
    console.log(res.data);
  }
  useEffect(() => {
    empData()
  }, [])

  const navigate = useNavigate();
  const Listemp = () => {
    navigate('/dashboard/employees', { state: { id: empId } });
  }
  const Listdept = () => {
    navigate('/dashboard/department', { state: { id: empId } });
  }
  const Lreq = () => {
    navigate('/dashboard/leavetype', { state: { id: empId } });
  }
  const PendingReq1 = () => {
    navigate('/dashboard/leaveReq/pendingReq', { state: { id: empId } });
  }
  const ApprovedReq = () => {
    navigate('/dashboard/leavereq/approvedReq', { state: { id: empId } });
  }

  // Example data for the pie chart
  const pieChartData = [
    { name: 'Monday', value: 12 },
    { name: 'Tuesday', value: 13 },
    { name: 'Wednesday', value: 9 },
    { name: 'Thursday', value: 10 },
    { name: 'Friday', value: 8 },
    { name: 'Saturday', value: 9 },
    { name: 'Sunday', value: 0 }
  ];

  // Colors for the pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];



  return (
    <>
      {data.map((item, index) => {
        return (
          <div>
            <div className='p-2 d-flex justify-content-center shadow'>
              <h4>​🇪​​🇲​​🇵​​🇱​​🇴​​🇾​​🇪​​🇪​ ​🇲​​🇦​​🇳​​🇦​​🇬​​🇪​​🇲​​🇪​​🇳​​🇹​ ​🇸​​🇾​​🇸​​🇹​​🇪​​🇲​</h4>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '3rem', margin: '2rem' }}>
              <Card
                style={{ width: '18rem', backgroundImage: 'linear-gradient(to right, #ff9a9e, #fad0c4)' }}
                className="mb-2"
                onClick={Listemp}
              >
                <Card.Header><h5>𝙻𝚒𝚜𝚝𝚎𝚍 𝙴𝚖𝚙𝚕𝚘𝚢𝚎𝚎</h5></Card.Header>
                <Card.Body>
                  <Card.Title style={{ fontSize: '2.5em' }}>{item.emp_row_count}</Card.Title>
                </Card.Body>
              </Card>

              <Card
                style={{
                  width: '18rem',
                  backgroundImage: 'linear-gradient(to right, #FFD700, #FFA500)', // Example gradient from gold to orange
                }}
                className="mb-2"
                onClick={Listdept}
              >
                <Card.Header><h5>𝙻𝚒𝚜𝚝𝚎𝚍 𝙳𝚎𝚙𝚊𝚛𝚝𝚖𝚎𝚗𝚝</h5></Card.Header>
                <Card.Body>
                  <Card.Title style={{ fontSize: '2.5em' }}>{item.dept_row_count}</Card.Title>
                </Card.Body>
              </Card>

              <Card
                style={{
                  width: '18rem',
                  backgroundImage: 'linear-gradient(to right, #4CAF50, #8BC34A, #CDDC39, #FFEB3B)', // Multi-color gradient of green
                }}
                className="mb-2"
                onClick={Lreq}
              >
                <Card.Header><h5>𝙻𝚒𝚜𝚝𝚎𝚍 𝙻𝚎𝚊𝚟𝚎 </h5></Card.Header>
                <Card.Body>
                  <Card.Title style={{ fontSize: '2.5em' }}>{item.leave_row_count}</Card.Title>
                </Card.Body>
              </Card>

            </div>
            <hr></hr>
            <div className='p-0.5 d-flex justify-content-center'>
              <h4>ꜱᴛᴀᴛᴜꜱ</h4>
            </div>
            <hr></hr>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '3rem'}}>
              <div style={{ margin: "1rem" }}>
                <Card
                  style={{
                    width: '18rem',
                    backgroundImage: 'linear-gradient(to right, #64B5F6, #42A5F5, #2196F3, #1E88E5)', // Multi-color gradient of blue
                  }}
                  className="mb-2 bg-info"
                  onClick={PendingReq1}
                >
                  <Card.Header>𝙿𝚎𝚗𝚍𝚒𝚗𝚐 𝚁𝚎𝚚𝚞𝚎𝚜𝚝</Card.Header>
                  <Card.Body>
                    <Card.Title style={{ fontSize: '2em' }}>{item.pending_row_count}</Card.Title>
                  </Card.Body>
                </Card>

                <Card
                  style={{
                    width: '18rem',
                    backgroundImage: 'linear-gradient(to right, #FFD180, #FFAB40, #FF9100, #FF6D00)', // Multi-color gradient of orange
                    animation: 'animateBackground 10s linear infinite', // Animation for the background
                  }}
                  className="mb-2"
                  onClick={ApprovedReq}
                >
                  <Card.Header>𝙰𝚙𝚙𝚛𝚘𝚟𝚎𝚍 𝙻𝚎𝚊𝚟𝚎</Card.Header>
                  <Card.Body>
                    <Card.Title style={{ fontSize: '2em' }}>{item.approved_row_count}</Card.Title>
                  </Card.Body>
                </Card>

              </div>
              <div style={{}}>
                <PieChart width={700} height={250}>
                  <Pie
                    dataKey="value"
                    isAnimationActive={false}
                    data={pieChartData}
                    cx={350}
                    cy={100}
                    outerRadius={70}
                    fill="#8884d8"
                    label
                  >
                    {pieChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </div>
            </div>
          </div>
        )
      })}
    </>
  )
}