import React, { useState } from 'react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    // Store login time in localStorage
    localStorage.setItem('loginTime', new Date().getTime());
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    // Calculate session duration
    const loginTime = localStorage.getItem('loginTime');
    const logoutTime = new Date().getTime();
    const sessionDuration = (logoutTime - parseInt(loginTime)) / 1000; // Convert milliseconds to seconds

    // Clear login time from localStorage
    localStorage.removeItem('loginTime');

    // Display session duration
    console.log('Session Duration:', sessionDuration, 'seconds');

    // Update state
    setIsLoggedIn(false);
  };

  return (
    <div>
      {isLoggedIn ? (
        <button onClick={handleLogout}>Logout</button>
      ) : (
        <button onClick={handleLogin}>Login</button>
      )}
    </div>
  );
}

export default App;
